"""Power tests: the ki meter, the three special powers (Time Stop, Clones, Dragonfire) and how they
start, run, pause and end."""
import os, tempfile, unittest
from pathlib import Path
# Run without a window, sound card or GPU so the tests work on any machine (including a build server).
os.environ["SDL_VIDEODRIVER"] = "dummy"; os.environ["SDL_AUDIODRIVER"] = "dummy"; os.environ["NINJA_NO_GPU"] = "1"
import pygame
from ninja import game
from ninja.powers import KiMeter, KI_MAX, KI_PER_CUT

# One frame at 60 frames per second, in seconds.
DT = 1 / 60
def run(app, n, events=()):
    """Advance the game n frames, sending the same events on each frame."""
    for _ in range(n):
        app.step(DT, list(events))
def key(k):
    """Build a fake key-press event."""
    return pygame.event.Event(pygame.KEYDOWN, key=k, mod=0, unicode="", scancode=0)
def move(app, p):
    """Move the mouse cursor to point p for one frame."""
    app.step(DT, [pygame.event.Event(pygame.MOUSEMOTION, pos=p, rel=(0, 0), buttons=(0, 0, 0))])
def rclick():
    """Build a fake right-mouse-button click event."""
    return pygame.event.Event(pygame.MOUSEBUTTONDOWN, pos=(640, 360), button=3)

class Ki(unittest.TestCase):
    """The ki meter, which fills as you cut and is spent to use a power."""
    # Proves: the meter fills up to its maximum and no further, empties when spent, and ignores filling while locked.
    def test_fill_clamp_spend_lock(self):
        k = KiMeter()
        for _ in range(30): k.add(4)
        self.assertEqual(k.value, KI_MAX); self.assertTrue(k.full)
        k.locked = True; k.spend(); k.add(50)
        self.assertEqual(k.value, 0)

class Powers(unittest.TestCase):
    """Using powers inside a real 'path' game."""
    def setUp(self):
        """Use a throwaway save file, start a path game and play past the 'ready' countdown."""
        self.tmp = tempfile.TemporaryDirectory()
        game.SAVE_PATH = Path(self.tmp.name) / "save.json"
        self.app = game.App()
        self.app.go(lambda: game.Play(self.app, "path"))
        self.p = self.app.scene
        run(self.app, 80)  # past "ready"

    def tearDown(self):
        """Shut pygame down and delete the temporary save folder."""
        pygame.quit(); self.tmp.cleanup()

    # Proves: a power can't start with a non-full meter, or while the game is paused.
    def test_no_power_without_full_meter_or_when_paused(self):
        p = self.p
        self.assertFalse(p.use_power("timestop"))
        p.ki.value = KI_MAX; p.paused = True
        run(self.app, 1, [key(pygame.K_w)])
        self.assertIsNone(p.power); self.assertEqual(p.ki.value, KI_MAX)

    # Proves: classic mode has no ki meter.
    def test_classic_has_no_ki(self):
        self.app.go(lambda: game.Play(self.app, "classic"))
        self.assertIsNone(self.app.scene.ki)

    # Proves: Time Stop freezes everything, and the fruit your cursor touched are cut afterwards in the order you touched them.
    def test_timestop_freezes_world_and_cuts_touched_in_order(self):
        p, app = self.p, self.app
        p.queue.clear(); p.spawn_t = 99
        a = p.w.throw("apple", 400, 360, 0, 0, static=True)
        b = p.w.throw("orange", 800, 360, 0, 0, static=True)
        c = p.w.throw("kiwi", 640, 120, 0, 0, static=True)  # not on the path
        p.ki.value = KI_MAX
        run(app, 1, [key(pygame.K_q)])
        self.assertEqual(p.power.name, "timestop")
        self.assertEqual(p.w.time_scale(), 0.0)
        for x in range(900, 299, -25):  # right to left: b is touched first
            move(app, (x, 360))
        self.assertTrue(a.alive and b.alive)   # nothing cut while time is stopped
        order, hit = [], p.hit
        p.hit = lambda body, seg: (order.append(body), hit(body, seg))
        run(app, int(3.2 / DT) + 10)
        self.assertFalse(a.alive); self.assertFalse(b.alive); self.assertTrue(c.alive)
        self.assertEqual(order, [b, a])
        self.assertIsNone(p.power)

    # Proves: Time Stop with nothing touched ends normally and empties the meter.
    def test_timestop_empty_path_ends_cleanly(self):
        p, app = self.p, self.app
        p.ki.value = KI_MAX
        run(app, 1, [key(pygame.K_q)])
        run(app, int(3.5 / DT))
        self.assertIsNone(p.power); self.assertEqual(p.ki.value, 0)

    # Proves: the Clones power slices fruit but leaves bombs alone.
    def test_clones_cut_fruit_never_bombs(self):
        p, app = self.p, self.app
        p.queue.clear(); p.spawn_t = 99
        f = p.w.throw("apple", 500, 300, 0, 0, static=True)
        bomb = p.w.throw("bomb", 800, 300, 0, 0, static=True)
        p.ki.value = KI_MAX
        run(app, 1, [key(pygame.K_w)])
        run(app, int(5.2 / DT))
        self.assertFalse(f.alive); self.assertTrue(bomb.alive)

    # Proves: Dragonfire spreads from the first cut fruit to nearby ones only.
    def test_dragonfire_chain_within_radius_only(self):
        p, app = self.p, self.app
        p.queue.clear(); p.spawn_t = 99
        first = p.w.throw("apple", 400, 300, 0, 0, static=True)
        near = p.w.throw("orange", 520, 300, 0, 0, static=True)   # 120 px away -> ignites
        far = p.w.throw("kiwi", 900, 300, 0, 0, static=True)      # 380 px away -> stays
        p.ki.value = KI_MAX
        run(app, 1, [key(pygame.K_e)])
        p.hit(first, (300, 300, 450, 300))
        run(app, 30)
        self.assertFalse(near.alive); self.assertTrue(far.alive)

    # The next few tests check when powers must NOT work.
    # --- review focus 1 and 2 ---
    # Proves: powers can't start during the countdown, the death animation or the ending.
    def test_no_power_in_ready_dying_or_ending(self):
        p = self.p
        for state in ("ready", "dying", "ending"):
            p.state, p.ki.value = state, KI_MAX
            run(self.app, 1, [key(pygame.K_e), rclick()])
            self.assertIsNone(p.power, state); self.assertEqual(p.ki.value, KI_MAX, state)

    # Proves: pressing Q while paused still means 'quit to menu', not Time Stop.
    def test_q_while_paused_still_quits_to_menu(self):
        p = self.p
        p.ki.value = KI_MAX; p.paused = True
        run(self.app, 1, [key(pygame.K_q)])
        self.assertIsInstance(self.app.scene, game.Menu); self.assertEqual(p.ki.value, KI_MAX)

    # Proves: right-click triggers the power you used last (Time Stop by default).
    def test_right_click_uses_last_power(self):
        p = self.p
        p.ki.value = KI_MAX
        run(self.app, 1, [rclick()])
        self.assertEqual(p.power.name, "timestop")
        p.power = None; p.ki.locked = False; p.last_power = "clones"; p.ki.value = KI_MAX
        run(self.app, 1, [rclick()])
        self.assertEqual(p.power.name, "clones")

    # Proves: if the Time Stop path crosses only a bomb, it costs a life and the power ends cleanly.
    def test_timestop_path_over_bomb_only_costs_a_life_and_ends(self):
        p, app = self.p, self.app
        p.queue.clear(); p.spawn_t = 99
        bomb = p.w.throw("bomb", 640, 360, 0, 0, static=True)
        p.ki.value = KI_MAX
        run(app, 1, [key(pygame.K_q)])
        for x in range(500, 801, 25):
            move(app, (x, 360))
        run(app, int(3.3 / DT))
        self.assertFalse(bomb.alive); self.assertEqual(p.lives, 2)
        self.assertIsNone(p.power); self.assertEqual(p.ki.value, 0); self.assertFalse(p.ki.locked)

    # Proves: cuts fill the meter normally, but not while a power is running.
    def test_cuts_fill_ki_but_not_while_a_power_runs(self):
        p = self.p
        p.queue.clear(); p.spawn_t = 99
        p.hit(p.w.throw("apple", 400, 300, 0, 0, static=True), (300, 300, 500, 300))
        self.assertEqual(p.ki.value, KI_PER_CUT)
        p.ki.value = KI_MAX
        self.assertTrue(p.use_power("clones"))
        p.hit(p.w.throw("apple", 400, 500, 0, 0, static=True), (300, 500, 500, 500))
        self.assertEqual(p.ki.value, 0)

    # The next tests check what happens when something interrupts a running power.
    # --- exits and pauses mid-power ---
    # Proves: if the run ends during a power, the power stops and time goes back to normal speed.
    def test_run_ending_mid_power_ends_it_and_restores_time(self):
        p = self.p
        p.ki.value = KI_MAX
        self.assertTrue(p.use_power("timestop"))
        run(self.app, 5)
        p.state = "dying"
        run(self.app, 1)
        self.assertIsNone(p.power); self.assertFalse(p.ki.locked); self.assertEqual(p.w.time_scale(), 1.0)

    # Proves: pausing freezes a power's timer and resuming continues it.
    def test_pause_mid_power_keeps_it_and_resumes(self):
        p = self.p
        p.ki.value = KI_MAX
        self.assertTrue(p.use_power("clones"))
        run(self.app, 10)
        pw, t = p.power, p.power.t
        p.paused = True
        run(self.app, 60)
        self.assertIs(p.power, pw); self.assertEqual(pw.t, t); self.assertTrue(p.ki.locked)
        p.paused = False
        run(self.app, 5)
        self.assertIs(p.power, pw); self.assertGreater(pw.t, t)

    # Proves: Time Stop also freezes the frenzy and double-points timers and stops new fruit.
    def test_timestop_holds_frenzy_and_power_up_timers(self):
        app = self.app
        app.go(lambda: game.Play(app, "arcade"))
        p = app.scene
        run(app, 80)
        p.queue.clear(); p.spawn_t = 99
        p.frenzy, p.double = 4.5, 8.0
        p.ki.value = KI_MAX
        self.assertTrue(p.use_power("timestop"))
        run(app, 2)
        n, frenzy, double = len(p.w.bodies), p.frenzy, p.double
        run(app, int(2.8 / DT))
        self.assertEqual(p.power.name, "timestop")
        self.assertEqual(len(p.w.bodies), n); self.assertEqual(p.frenzy, frenzy); self.assertEqual(p.double, double)


class CutLod(unittest.TestCase):
    """A storm of cuts thins the juice per cut; a single cut looks exactly as before."""
    """A storm of cuts thins the juice per cut; a single cut looks exactly as before."""
    def setUp(self):
        """Use a throwaway save file and start the game at the menu."""
        self.tmp = tempfile.TemporaryDirectory()
        game.SAVE_PATH = Path(self.tmp.name) / "save.json"
        self.app = game.App()

    def tearDown(self):
        """Shut pygame down and delete the temporary save folder."""
        pygame.quit(); self.tmp.cleanup()

    def cut_cost(self, w):
        """Cut one apple and return how many particles that cut created."""
        b = w.throw("apple", 640, 360, 0, 0, static=True)
        n = len(w.particles.items)
        w.cut(b, 600, 360, 680, 360)
        return len(w.particles.items) - n

    # Proves: a lone cut makes the full juice, rapid cuts make less (to stay fast), and the full juice returns after a pause.
    def test_single_cut_unchanged_rapid_cuts_lighter(self):
        from ninja.fx import Particles
        w = game.World(self.app)
        w.particles.items.clear()
        ref = Particles(self.app.art)
        if self.app.art.splashes:
            ref.splash(640, 360, (1, 1, 1), 0, 1, 40)
        ref.juice(640, 360, (1, 1, 1), 0, 1, spread=44)
        self.assertEqual(self.cut_cost(w), len(ref.items))
        for _ in range(20):
            w.particles.items.clear()
            last = self.cut_cost(w)
        self.assertLess(last, len(ref.items) * 0.6)
        for _ in range(240):  # heat decays on real time: back to full juice
            w.update(DT, DT)
        w.particles.items.clear()
        self.assertEqual(self.cut_cost(w), len(ref.items))

    # Proves: the number of cut halves on screen never exceeds the limit.
    def test_halves_capped(self):
        w = game.World(self.app)
        for _ in range(40):
            self.cut_cost(w)
        self.assertLessEqual(len(w.halves), game.World.MAX_HALVES)
